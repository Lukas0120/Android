#!/system/bin/sh
# STRP - SQLite3™ Compiled by CRANKV2
# Nothing big just placing latest customized sqlite binary

arch=$(getprop ro.product.cpu.abi)
IS64BIT=$(getprop ro.build.version.sdk)
ui_print ""
sleep 1
ui_print "
░██████╗████████╗██████╗░██████╗░
██╔════╝╚══██╔══╝██╔══██╗██╔══██╗
╚█████╗░░░░██║░░░██████╔╝██████╔╝
░╚═══██╗░░░██║░░░██╔══██╗██╔═══╝░
██████╔╝░░░██║░░░██║░░██║██║░░░░░
╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░░░░"
sleep 1
ui_print ""
ui_print "
░██████╗░██████╗░██╗░░░░░
██╔════╝██╔═══██╗██║░░░░░
╚█████╗░██║██╗██║██║░░░░░
░╚═══██╗╚██████╔╝██║░░░░░
██████╔╝░╚═██╔═╝░███████╗
╚═════╝░░░░╚═╝░░░╚══════╝"
ui_print ""
sleep 1
ui_print "
██████╗░░░░░░██╗██╗░░██╗██╗░░░██████╗░
╚════██╗░░░░██╔╝██║░██╔╝██║░░░╚════██╗
░█████╔╝░░░██╔╝░██║██╔╝░██║░░░░░███╔═╝
░╚═══██╗░░░███████║███████║░░░██╔══╝░░
██████╔╝██╗╚════██║╚════██║██╗███████╗
╚═════╝░╚═╝░░░░░╚═╝░░░░░╚═╝╚═╝╚══════╝"
sleep 1.5
ui_print "Powered By STRPxDEVS"
ui_print "▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰"
ui_print "Checking architecture ..."
sleep 2
ui_print ""

# Check if the device is running on Android SDK version 21 or higher (64-bit)
if [ "$IS64BIT" -ge 21 ]; then
    if [ "$arch" = "arm64-v8a" ] || [ "$arch" = "aarch64" ]; then
        tar -xf "$MODPATH/sqlite_aarch64.tar.xz" -C "$MODPATH"
        ui_print "Placed files for $arch"
        set_permissions
    elif [ "$arch" = "armeabi-v7a" ] || [ "$arch" = "armv7a" ]; then
        ui_print "Error: This installation is only supported on x64 (aarch64) bit devices."
        ui_print "Please ask for help in the STRP x UNIVERSE group."
        exit 1
    elif [ "$arch" = "x86_64" ]; then
        ui_print "Error: This installation is only supported on x64 (aarch64) bit devices."
        ui_print "Please ask for help in the STRP x UNIVERSE group."
        exit 1
    elif [ "$arch" = "x86" ]; then
        ui_print "Error: This installation is only supported on x64 (aarch64) bit devices."
        ui_print "Please ask for help in the STRP x UNIVERSE group."
        exit 1
    else
        ui_print "Unsupported architecture: $arch"
    fi
fi

sleep 1
# Remove unnecessary files
rm -rf "$MODDIR/sqlite_x86_64.tar.xz"
rm -rf "$MODDIR/sqlite_armv7a.tar.xz"
rm -rf "$MODDIR/sqlite_aarch64.tar.xz"
rm -rf "$MODDIR/sqlite_x86.tar.xz"
  

set_permissions (){
  set_perm_recursive "${MODPATH}/system/bin" 0 0 0777 0755
}

SKIPUNZIP=0
unzip -qjo "${ZIPFILE}" 'common/functions.sh' -d "${TMPDIR}" >&2
. "${TMPDIR}/functions.sh"